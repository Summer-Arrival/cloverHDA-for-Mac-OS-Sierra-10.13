Codec: Realtek ALC299
Address: 0
AFG Function Id: 0x1 (unsol 1)
Vendor Id: 0x10ec0299
Subsystem Id: 0x17aa3801
Revision Id: 0x100002


You must change the Layout to 13  in the DSDT patch HDEF.
Kext Patched by Insanelydeepak 

Notes for installation :

2.Install ALCfix 
